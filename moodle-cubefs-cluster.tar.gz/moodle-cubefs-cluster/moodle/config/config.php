<?php  // Moodle configuration file - Cluster Setup dengan CubeFS

unset($CFG);
global $CFG;
$CFG = new stdClass();

// ─── Database Configuration ──────────────────────────────────────────────────
$CFG->dbtype    = 'mysqli';
$CFG->dblibrary = 'native';
$CFG->dbhost    = getenv('MOODLE_DB_HOST') ?: 'mysql-primary';
$CFG->dbname    = getenv('MOODLE_DB_NAME') ?: 'moodle';
$CFG->dbuser    = getenv('MOODLE_DB_USER') ?: 'moodle';
$CFG->dbpass    = getenv('MOODLE_DB_PASSWORD') ?: '';
$CFG->prefix    = 'mdl_';
$CFG->dboptions = [
    'dbport'    => (int)(getenv('MOODLE_DB_PORT') ?: 3306),
    'dbsocket'  => '',
    'dbcollation' => 'utf8mb4_unicode_ci',
    'connecttimeout' => 10,
];

// ─── URL & Path ───────────────────────────────────────────────────────────────
$CFG->wwwroot   = getenv('MOODLE_WWWROOT') ?: 'http://localhost';
$CFG->dataroot  = getenv('MOODLE_DATAROOT') ?: '/var/moodledata';
$CFG->directorypermissions = 02777;

// ─── Admin Configuration ─────────────────────────────────────────────────────
$CFG->admin = 'admin';

// ─── Session Handling via Redis ──────────────────────────────────────────────
// PENTING: Redis digunakan agar session terbagi antar semua Moodle nodes
$CFG->session_handler_class = '\core\session\redis';
$CFG->session_redis_host    = getenv('REDIS_HOST') ?: 'redis';
$CFG->session_redis_port    = (int)(getenv('REDIS_PORT') ?: 6379);
$CFG->session_redis_database = 0;
$CFG->session_redis_auth    = getenv('REDIS_PASSWORD') ?: '';
$CFG->session_redis_prefix  = 'moodle_sess_';
$CFG->session_redis_acquire_lock_timeout     = 120;
$CFG->session_redis_acquire_lock_retry       = 100;
$CFG->session_redis_acquire_lock_warn        = 0;
$CFG->session_redis_lock_expire             = 7200;
$CFG->session_redis_lock_delete_keys_on_expire = false;
$CFG->session_redis_serializer_use_igbinary  = false;
$CFG->session_redis_compressor               = \core\session\redis::COMPRESSION_NONE;

// ─── Caching (MUC) via Redis ──────────────────────────────────────────────────
// Application cache store backend
$CFG->alternative_cache_factory_class = '';

// ─── Performance & Cluster Settings ─────────────────────────────────────────
$CFG->slasharguments         = 0;
$CFG->cookiesecure           = false;    // Set true jika HTTPS
$CFG->cookiehttponly         = true;

// Reverse Proxy / Load Balancer
$CFG->reverseproxy           = true;
$CFG->reverseproxyhost       = getenv('MOODLE_WWWROOT') ?: 'http://localhost';

// Trusted IP ranges (nginx load balancer)
$CFG->getremoteaddrconf      = 7;  // GETREMOTEADDR_SKIP_HTTP_X_FORWARDED_FOR
$CFG->trustedproxyips        = '172.31.0.10,127.0.0.1';

// ─── Cron Settings ────────────────────────────────────────────────────────────
// Hanya node 1 yang menjalankan cron (mencegah duplicate jobs)
$nodeId = (int)(getenv('NODE_ID') ?: 1);
if ($nodeId !== 1) {
    $CFG->cronclionly = true;
}

// ─── File Security ────────────────────────────────────────────────────────────
$CFG->disableupdatenotifications = true;
$CFG->disableupdateautodeploy    = true;

// ─── Cluster-specific ─────────────────────────────────────────────────────────
$CFG->noreplyaddress = getenv('MOODLE_ADMIN_EMAIL') ?: 'noreply@example.com';
$CFG->smtphosts      = '';
$CFG->smtpport       = 25;

// ─── OPcache Revalidation ─────────────────────────────────────────────────────
// Penting untuk cluster: pastikan PHP membaca file baru dari shared storage
@ini_set('opcache.revalidate_freq', '0');

// ─── Logging (opsional) ──────────────────────────────────────────────────────
// $CFG->debugsmtp     = true;
// $CFG->debugdisplay  = false;
// $CFG->debug         = (E_ALL | E_STRICT);

require_once(__DIR__ . '/lib/setup.php');
// === JANGAN TAMBAHKAN APAPUN SETELAH BARIS INI ===

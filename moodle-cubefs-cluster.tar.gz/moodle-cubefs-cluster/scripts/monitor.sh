#!/bin/bash
# ============================================================
# Script Monitoring Moodle Cluster
# ============================================================

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'

INSTALL_DIR="/opt/moodle-cluster"
ENV_FILE="${INSTALL_DIR}/.env"
[ -f "$ENV_FILE" ] && source "$ENV_FILE"

clear
echo -e "${BOLD}${CYAN}"
echo "╔══════════════════════════════════════════════════════╗"
echo "║         MOODLE CLUSTER - STATUS MONITOR              ║"
echo "╚══════════════════════════════════════════════════════╝"
echo -e "${NC}"
echo -e "Waktu: $(date '+%Y-%m-%d %H:%M:%S')"
echo ""

# ─── Docker Containers ──────────────────────────────────────
echo -e "${BOLD}${CYAN}[ DOCKER CONTAINERS ]${NC}"
docker compose -f "${INSTALL_DIR}/docker-compose.cubefs.yml" \
               -f "${INSTALL_DIR}/docker-compose.moodle.yml" ps --format \
    "table {{.Name}}\t{{.Status}}\t{{.Ports}}" 2>/dev/null \
    || docker ps --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}" | grep -E "moodle|cubefs|redis|mysql|nginx"

echo ""

# ─── Moodle Nodes Health ─────────────────────────────────────
echo -e "${BOLD}${CYAN}[ MOODLE NODES HEALTH ]${NC}"
for node in moodle-node1 moodle-node2 moodle-node3; do
    STATUS=$(docker inspect --format='{{.State.Health.Status}}' "$node" 2>/dev/null || echo "unknown")
    RUNNING=$(docker inspect --format='{{.State.Running}}' "$node" 2>/dev/null || echo "false")
    
    if [ "$RUNNING" = "true" ]; then
        if [ "$STATUS" = "healthy" ]; then
            echo -e "  ${node}: ${GREEN}● healthy${NC}"
        elif [ "$STATUS" = "starting" ]; then
            echo -e "  ${node}: ${YELLOW}● starting${NC}"
        else
            echo -e "  ${node}: ${YELLOW}● ${STATUS}${NC}"
        fi
    else
        echo -e "  ${node}: ${RED}● stopped${NC}"
    fi
done

echo ""

# ─── MySQL Replication Status ────────────────────────────────
echo -e "${BOLD}${CYAN}[ MYSQL REPLICATION STATUS ]${NC}"
REPL_STATUS=$(docker exec moodle-mysql-replica \
    mysql -u root -p"${MYSQL_ROOT_PASSWORD:-RootPass@123}" \
    -e "SHOW SLAVE STATUS\G" 2>/dev/null \
    | grep -E "Slave_IO_Running|Slave_SQL_Running|Seconds_Behind_Master")

if [ -n "$REPL_STATUS" ]; then
    echo "$REPL_STATUS" | while IFS= read -r line; do
        if echo "$line" | grep -q "Yes"; then
            echo -e "  ${GREEN}${line}${NC}"
        elif echo "$line" | grep -q "No"; then
            echo -e "  ${RED}${line}${NC}"
        else
            echo "  $line"
        fi
    done
else
    echo -e "  ${YELLOW}Tidak dapat membaca status replikasi${NC}"
fi

echo ""

# ─── Redis Stats ─────────────────────────────────────────────
echo -e "${BOLD}${CYAN}[ REDIS CACHE STATS ]${NC}"
REDIS_INFO=$(docker exec moodle-redis \
    redis-cli -a "${REDIS_PASSWORD:-RedisPass@123}" info stats 2>/dev/null \
    | grep -E "connected_clients|used_memory_human|keyspace_hits|keyspace_misses|total_commands_processed" \
    | head -5)
echo "$REDIS_INFO" | while IFS= read -r line; do
    echo "  $line"
done

echo ""

# ─── CubeFS Cluster Status ───────────────────────────────────
echo -e "${BOLD}${CYAN}[ CUBEFS CLUSTER STATUS ]${NC}"
CUBEFS_STATUS=$(curl -sf "http://localhost:17010/admin/getCluster" 2>/dev/null | jq -r \
    '.data | "  DataNodes: \(.dataNodeCount) | MetaNodes: \(.metaNodeCount) | VolCount: \(.volCount)"' \
    2>/dev/null || echo "  Tidak dapat terhubung ke CubeFS master")
echo "$CUBEFS_STATUS"

echo ""

# ─── CubeFS Mount ────────────────────────────────────────────
echo -e "${BOLD}${CYAN}[ CUBEFS MOUNT STATUS ]${NC}"
MOUNT_POINT="/mnt/cubefs-moodledata"
if mountpoint -q "$MOUNT_POINT" 2>/dev/null; then
    USAGE=$(df -h "$MOUNT_POINT" 2>/dev/null | tail -1 | awk '{print "Used: "$3" / "$2" ("$5")"}')
    echo -e "  ${GREEN}● Mounted at ${MOUNT_POINT}${NC}"
    echo "  $USAGE"
else
    echo -e "  ${YELLOW}● Tidak ter-mount (cubefs-client mungkin dalam proses)${NC}"
fi

echo ""

# ─── Nginx LB Status ─────────────────────────────────────────
echo -e "${BOLD}${CYAN}[ NGINX LOAD BALANCER ]${NC}"
if curl -sf "http://localhost/nginx-health" &>/dev/null; then
    echo -e "  ${GREEN}● Aktif dan melayani request${NC}"
    
    # Hitung request dari log
    REQ_COUNT=$(docker exec moodle-nginx \
        tail -100 /var/log/nginx/access.log 2>/dev/null | wc -l || echo "0")
    echo "  Request (100 terakhir): ${REQ_COUNT}"
else
    echo -e "  ${RED}● Tidak merespons${NC}"
fi

echo ""

# ─── Resource Usage ──────────────────────────────────────────
echo -e "${BOLD}${CYAN}[ RESOURCE USAGE (TOP 5) ]${NC}"
docker stats --no-stream --format \
    "table {{.Name}}\t{{.CPUPerc}}\t{{.MemUsage}}\t{{.NetIO}}" 2>/dev/null \
    | grep -E "NAME|moodle|cubefs|redis|mysql|nginx" | head -10

echo ""
echo -e "${YELLOW}Tekan Ctrl+C untuk keluar. Refresh: watch -n 10 ./scripts/monitor.sh${NC}"

#!/bin/bash
# ============================================================
# MOODLE CLUSTER - SCRIPT INSTALASI LENGKAP
# Stack: Moodle 4.3 + CubeFS + MySQL + Redis + Nginx
# ============================================================

set -euo pipefail

# ─── Warna ───────────────────────────────────────────────────
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

# ─── Logging ─────────────────────────────────────────────────
LOG_FILE="/var/log/moodle-cluster-install.log"
mkdir -p /var/log

log()     { echo -e "${GREEN}[INFO]${NC} $*" | tee -a "$LOG_FILE"; }
warn()    { echo -e "${YELLOW}[WARN]${NC} $*" | tee -a "$LOG_FILE"; }
error()   { echo -e "${RED}[ERROR]${NC} $*" | tee -a "$LOG_FILE"; exit 1; }
section() { echo -e "\n${BLUE}${BOLD}══════════════════════════════════════${NC}" | tee -a "$LOG_FILE"
            echo -e "${CYAN}${BOLD}  $*${NC}" | tee -a "$LOG_FILE"
            echo -e "${BLUE}${BOLD}══════════════════════════════════════${NC}" | tee -a "$LOG_FILE"; }

# ─── Cek Root ────────────────────────────────────────────────
if [ "$EUID" -ne 0 ]; then
    error "Script ini harus dijalankan sebagai root: sudo $0"
fi

# ─── Cek OS ──────────────────────────────────────────────────
if ! grep -qiE 'ubuntu|debian' /etc/os-release 2>/dev/null; then
    warn "Script ini dioptimalkan untuk Ubuntu/Debian. Lanjutkan dengan risiko sendiri."
fi

# ─── Variabel Default ────────────────────────────────────────
INSTALL_DIR="/opt/moodle-cluster"
CUBEFS_MOUNT="/mnt/cubefs-moodledata"
COMPOSE_VERSION="2.24.0"

section "LANGKAH 1: Memeriksa Persyaratan Sistem"

# ─── Cek RAM ─────────────────────────────────────────────────
TOTAL_RAM_GB=$(awk '/MemTotal/ { printf "%.0f", $2/1024/1024 }' /proc/meminfo)
if [ "$TOTAL_RAM_GB" -lt 8 ]; then
    warn "RAM kurang dari 8GB (${TOTAL_RAM_GB}GB terdeteksi). Minimum yang direkomendasikan: 16GB"
    read -p "Lanjutkan? (y/N): " confirm
    [[ "$confirm" =~ ^[Yy]$ ]] || exit 1
fi
log "RAM: ${TOTAL_RAM_GB}GB ✓"

# ─── Cek Disk ────────────────────────────────────────────────
DISK_FREE_GB=$(df / | awk 'NR==2 {printf "%.0f", $4/1024/1024}')
if [ "$DISK_FREE_GB" -lt 50 ]; then
    warn "Disk kosong kurang dari 50GB (${DISK_FREE_GB}GB tersedia)"
fi
log "Disk kosong: ${DISK_FREE_GB}GB ✓"

section "LANGKAH 2: Install Dependencies"

# ─── Update System ────────────────────────────────────────────
log "Memperbarui package list..."
apt-get update -qq

# ─── Install Dependencies ────────────────────────────────────
log "Menginstall dependencies..."
apt-get install -y --no-install-recommends \
    curl \
    wget \
    git \
    unzip \
    ca-certificates \
    gnupg \
    lsb-release \
    fuse3 \
    libfuse-dev \
    mysql-client \
    redis-tools \
    jq \
    htop \
    net-tools \
    2>&1 | tee -a "$LOG_FILE"

# ─── Aktifkan FUSE module ─────────────────────────────────────
log "Mengaktifkan FUSE kernel module..."
modprobe fuse || warn "FUSE module gagal dimuat (mungkin sudah aktif)"
echo "fuse" >> /etc/modules-load.d/fuse.conf 2>/dev/null || true

section "LANGKAH 3: Install Docker & Docker Compose"

# ─── Cek apakah Docker sudah terinstall ──────────────────────
if command -v docker &>/dev/null; then
    DOCKER_VER=$(docker --version | grep -oP '\d+\.\d+\.\d+' | head -1)
    log "Docker sudah terinstall: v${DOCKER_VER} ✓"
else
    log "Menginstall Docker Engine..."
    
    # Remove old versions
    apt-get remove -y docker docker-engine docker.io containerd runc 2>/dev/null || true
    
    # Add Docker GPG key
    install -m 0755 -d /etc/apt/keyrings
    curl -fsSL https://download.docker.com/linux/ubuntu/gpg \
        | gpg --dearmor -o /etc/apt/keyrings/docker.gpg
    chmod a+r /etc/apt/keyrings/docker.gpg
    
    # Add Docker repository
    echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] \
        https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable" \
        | tee /etc/apt/sources.list.d/docker.list > /dev/null
    
    # Install Docker
    apt-get update -qq
    apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin
    
    # Enable & start Docker
    systemctl enable docker
    systemctl start docker
    
    log "Docker berhasil diinstall ✓"
fi

# ─── Install Docker Compose ──────────────────────────────────
if command -v docker-compose &>/dev/null || docker compose version &>/dev/null 2>&1; then
    log "Docker Compose sudah terinstall ✓"
else
    log "Menginstall Docker Compose v${COMPOSE_VERSION}..."
    mkdir -p /usr/local/lib/docker/cli-plugins
    curl -SL "https://github.com/docker/compose/releases/download/v${COMPOSE_VERSION}/docker-compose-linux-$(uname -m)" \
        -o /usr/local/lib/docker/cli-plugins/docker-compose
    chmod +x /usr/local/lib/docker/cli-plugins/docker-compose
    log "Docker Compose berhasil diinstall ✓"
fi

# ─── Optimasi Docker ─────────────────────────────────────────
log "Mengkonfigurasi Docker daemon..."
cat > /etc/docker/daemon.json <<'EOF'
{
  "log-driver": "json-file",
  "log-opts": {
    "max-size": "100m",
    "max-file": "5"
  },
  "default-ulimits": {
    "nofile": {
      "Name": "nofile",
      "Hard": 65535,
      "Soft": 65535
    }
  },
  "storage-driver": "overlay2"
}
EOF
systemctl reload docker

section "LANGKAH 4: Menyiapkan Direktori Project"

# ─── Setup Directory ─────────────────────────────────────────
log "Membuat direktori project di ${INSTALL_DIR}..."
mkdir -p "${INSTALL_DIR}"

# Copy project files ke install dir
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [ "$SCRIPT_DIR" != "$INSTALL_DIR" ]; then
    log "Menyalin file project..."
    cp -r "${SCRIPT_DIR}/." "${INSTALL_DIR}/"
fi

cd "${INSTALL_DIR}"

# ─── Buat log directories ─────────────────────────────────────
log "Membuat log directories..."
mkdir -p \
    cubefs/logs/{master1,master2,master3,metanode1,metanode2,metanode3,datanode1,datanode2,datanode3,client} \
    nginx/ssl

# ─── Buat CubeFS mount point ─────────────────────────────────
log "Membuat CubeFS mount point di ${CUBEFS_MOUNT}..."
mkdir -p "${CUBEFS_MOUNT}"
chmod 777 "${CUBEFS_MOUNT}"

section "LANGKAH 5: Konfigurasi Environment"

# ─── Generate .env jika belum ada ────────────────────────────
if [ ! -f "${INSTALL_DIR}/.env" ]; then
    log "File .env tidak ditemukan, membuat dengan nilai default..."
    cp "${SCRIPT_DIR}/.env.example" "${INSTALL_DIR}/.env" 2>/dev/null || true
fi

log "Memuat konfigurasi environment..."
source "${INSTALL_DIR}/.env"

# ─── Tampilkan konfigurasi ────────────────────────────────────
echo ""
echo -e "${CYAN}Konfigurasi yang akan digunakan:${NC}"
echo -e "  Domain     : ${DOMAIN:-localhost}"
echo -e "  Site Name  : ${MOODLE_SITE_NAME:-Moodle LMS}"
echo -e "  Admin User : ${MOODLE_ADMIN_USER:-admin}"
echo -e "  Install Dir: ${INSTALL_DIR}"
echo ""

section "LANGKAH 6: Memulai CubeFS Cluster"

log "Menjalankan CubeFS cluster..."
cd "${INSTALL_DIR}"

# Pull images lebih dulu
log "Menarik Docker images CubeFS..."
docker compose -f docker-compose.cubefs.yml pull

# Start CubeFS
docker compose -f docker-compose.cubefs.yml up -d --remove-orphans

log "Menunggu CubeFS Master nodes siap (60 detik)..."
sleep 30

# ─── Cek health CubeFS Masters ──────────────────────────────
log "Memeriksa status CubeFS masters..."
for i in 1 2 3; do
    PORT=$((17009 + i))
    MAX_RETRY=30
    RETRY=0
    until curl -sf "http://localhost:${PORT}/admin/getCluster" &>/dev/null; do
        RETRY=$((RETRY + 1))
        if [ $RETRY -ge $MAX_RETRY ]; then
            warn "Master${i} tidak merespons setelah ${MAX_RETRY} percobaan"
            break
        fi
        sleep 5
    done
    log "CubeFS Master${i}: OK ✓"
done

# ─── Buat Volume CubeFS untuk Moodle ──────────────────────────
log "Membuat volume CubeFS 'moodledata'..."
sleep 10  # Tunggu cluster stabil

# Buat volume via API
curl -sf "http://localhost:17010/admin/createVol?name=moodledata&owner=moodle&capacity=100&replicaNum=3&mpCount=3" \
    -X POST 2>&1 | tee -a "$LOG_FILE" || warn "Volume mungkin sudah ada"

# ─── Verifikasi Mount ─────────────────────────────────────────
log "Memverifikasi CubeFS FUSE mount..."
sleep 15
if mountpoint -q "${CUBEFS_MOUNT}" 2>/dev/null; then
    log "CubeFS mount berhasil di ${CUBEFS_MOUNT} ✓"
else
    warn "CubeFS FUSE mount belum aktif. Periksa container cubefs-client"
    docker logs cubefs-client --tail 50 2>&1 | tee -a "$LOG_FILE"
fi

# ─── Setup moodledata permissions ────────────────────────────
mkdir -p "${CUBEFS_MOUNT}"/{filedir,temp,cache,sessions,localcache,trashdir}
chmod -R 777 "${CUBEFS_MOUNT}"

section "LANGKAH 7: Memulai Moodle Stack"

log "Build Moodle Docker image..."
docker compose -f docker-compose.moodle.yml build --no-cache moodle1

log "Menarik Docker images untuk stack Moodle..."
docker compose -f docker-compose.moodle.yml pull --ignore-buildable

log "Menjalankan MySQL dan Redis..."
docker compose -f docker-compose.moodle.yml up -d mysql-primary mysql-replica redis

log "Menunggu MySQL primary siap (60 detik)..."
MAX_RETRY=60
RETRY=0
until docker exec moodle-mysql-primary mysqladmin ping -h localhost \
    -u root -p"${MYSQL_ROOT_PASSWORD:-RootPass@123}" --silent 2>/dev/null; do
    RETRY=$((RETRY + 1))
    if [ $RETRY -ge $MAX_RETRY ]; then
        error "MySQL tidak siap setelah ${MAX_RETRY} percobaan"
    fi
    echo -n "."
    sleep 3
done
echo ""
log "MySQL Primary: OK ✓"

log "Menunggu MySQL replica..."
sleep 20

log "Menjalankan Nginx Load Balancer..."
docker compose -f docker-compose.moodle.yml up -d nginx

log "Menjalankan Moodle Node 1 (melakukan instalasi)..."
docker compose -f docker-compose.moodle.yml up -d moodle1

log "Menunggu instalasi Moodle selesai (bisa memakan waktu 2-5 menit)..."
MAX_WAIT=600
WAITED=0
until curl -sf "http://localhost/login/index.php" &>/dev/null; do
    sleep 10
    WAITED=$((WAITED + 10))
    echo -n "."
    if [ $WAITED -ge $MAX_WAIT ]; then
        warn "Timeout menunggu Moodle. Cek log: docker logs moodle-node1"
        break
    fi
done
echo ""
log "Moodle Node 1: OK ✓"

log "Menjalankan Moodle Node 2 dan 3..."
docker compose -f docker-compose.moodle.yml up -d moodle2 moodle3

log "Menunggu semua Moodle nodes siap..."
sleep 30

section "LANGKAH 8: Verifikasi Instalasi"

echo ""
echo -e "${CYAN}Memeriksa status semua container...${NC}"
docker compose -f docker-compose.cubefs.yml ps
echo ""
docker compose -f docker-compose.moodle.yml ps

# ─── Health Checks ───────────────────────────────────────────
echo ""
log "Menjalankan health checks..."

# Cek Nginx
if curl -sf "http://localhost/nginx-health" &>/dev/null; then
    log "Nginx Load Balancer: ✓ OK"
else
    warn "Nginx tidak merespons"
fi

# Cek Moodle
if curl -sf "http://localhost/login/index.php" | grep -q "Moodle" &>/dev/null; then
    log "Moodle Application: ✓ OK"
else
    warn "Moodle tidak merespons dengan benar"
fi

# Cek MySQL
if docker exec moodle-mysql-primary mysqladmin ping -h localhost \
    -u root -p"${MYSQL_ROOT_PASSWORD:-RootPass@123}" --silent 2>/dev/null; then
    log "MySQL Primary: ✓ OK"
fi

# Cek Redis
if docker exec moodle-redis redis-cli -a "${REDIS_PASSWORD:-RedisPass@123}" ping 2>/dev/null | grep -q PONG; then
    log "Redis: ✓ OK"
fi

# Cek CubeFS
if curl -sf "http://localhost:17010/admin/getCluster" &>/dev/null; then
    log "CubeFS Cluster: ✓ OK"
fi

section "INSTALASI SELESAI!"

SERVER_IP=$(hostname -I | awk '{print $1}')
echo ""
echo -e "${GREEN}${BOLD}╔══════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}${BOLD}║       MOODLE CLUSTER BERHASIL DIINSTALL!         ║${NC}"
echo -e "${GREEN}${BOLD}╚══════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "${CYAN}Akses Moodle:${NC}"
echo -e "  URL          : http://${SERVER_IP}"
echo -e "  Admin User   : ${MOODLE_ADMIN_USER:-admin}"
echo -e "  Admin Pass   : ${MOODLE_ADMIN_PASSWORD:-Admin@Moodle123!}"
echo ""
echo -e "${CYAN}Komponen:${NC}"
echo -e "  Moodle Nodes : 3x (moodle1, moodle2, moodle3)"
echo -e "  MySQL        : Primary + Replica"
echo -e "  Redis        : Session cache"
echo -e "  CubeFS       : Shared storage di ${CUBEFS_MOUNT}"
echo ""
echo -e "${CYAN}Perintah berguna:${NC}"
echo -e "  Status     : docker compose -f ${INSTALL_DIR}/docker-compose.moodle.yml ps"
echo -e "  Logs       : docker logs moodle-node1 -f"
echo -e "  Stop       : cd ${INSTALL_DIR} && docker compose -f docker-compose.moodle.yml down"
echo -e "  Monitoring : ./scripts/monitor.sh"
echo ""
echo -e "${YELLOW}Log instalasi tersimpan di: ${LOG_FILE}${NC}"
echo ""

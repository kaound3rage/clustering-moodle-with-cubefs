-- ============================================================
-- MySQL Primary: Inisialisasi User & Replication
-- ============================================================

-- Buat user untuk replikasi
CREATE USER IF NOT EXISTS 'replicator'@'%' IDENTIFIED BY '${REPLICATION_PASSWORD}';
GRANT REPLICATION SLAVE ON *.* TO 'replicator'@'%';

-- Izin tambahan untuk Moodle user
GRANT ALL PRIVILEGES ON moodle.* TO 'moodle'@'%';

-- Optimasi untuk Moodle
ALTER DATABASE moodle CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

FLUSH PRIVILEGES;

-- Show master status untuk verifikasi
SHOW MASTER STATUS;

#!/bin/bash
# ============================================================
# Script Manajemen Moodle Cluster
# Usage: ./scripts/manage.sh [command]
# ============================================================

INSTALL_DIR="/opt/moodle-cluster"
ENV_FILE="${INSTALL_DIR}/.env"
[ -f "$ENV_FILE" ] && source "$ENV_FILE"

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'

log()   { echo -e "${GREEN}[manage]${NC} $*"; }
warn()  { echo -e "${YELLOW}[warn]${NC} $*"; }
error() { echo -e "${RED}[error]${NC} $*"; exit 1; }

usage() {
    echo -e "${BOLD}Penggunaan: $0 [command]${NC}"
    echo ""
    echo "Commands:"
    echo "  start          - Start semua services"
    echo "  stop           - Stop semua services"
    echo "  restart        - Restart semua services"
    echo "  status         - Lihat status semua container"
    echo "  logs [service] - Lihat logs (default: semua)"
    echo "  backup         - Backup database dan moodledata"
    echo "  restore [file] - Restore dari backup"
    echo "  moodle-cron    - Jalankan Moodle cron manual"
    echo "  db-shell       - Masuk ke MySQL shell"
    echo "  redis-cli      - Masuk ke Redis CLI"
    echo "  purge-cache    - Bersihkan semua cache Moodle"
    echo "  upgrade        - Upgrade Moodle ke versi terbaru"
    echo ""
}

case "${1:-help}" in

    start)
        log "Memulai CubeFS cluster..."
        docker compose -f "${INSTALL_DIR}/docker-compose.cubefs.yml" up -d
        sleep 10
        log "Memulai Moodle stack..."
        docker compose -f "${INSTALL_DIR}/docker-compose.moodle.yml" up -d
        log "Semua services dimulai ✓"
        ;;

    stop)
        warn "Menghentikan semua services..."
        docker compose -f "${INSTALL_DIR}/docker-compose.moodle.yml" down
        docker compose -f "${INSTALL_DIR}/docker-compose.cubefs.yml" down
        log "Semua services dihentikan"
        ;;

    restart)
        $0 stop
        sleep 5
        $0 start
        ;;

    status)
        echo -e "${BOLD}=== CubeFS Cluster ===${NC}"
        docker compose -f "${INSTALL_DIR}/docker-compose.cubefs.yml" ps
        echo ""
        echo -e "${BOLD}=== Moodle Stack ===${NC}"
        docker compose -f "${INSTALL_DIR}/docker-compose.moodle.yml" ps
        ;;

    logs)
        SERVICE="${2:-}"
        if [ -n "$SERVICE" ]; then
            docker logs "$SERVICE" -f --tail 100
        else
            docker compose -f "${INSTALL_DIR}/docker-compose.moodle.yml" logs -f --tail 50
        fi
        ;;

    backup)
        BACKUP_DIR="/opt/moodle-backups/$(date +%Y%m%d_%H%M%S)"
        mkdir -p "$BACKUP_DIR"
        
        log "Backup MySQL database..."
        docker exec moodle-mysql-primary mysqldump \
            -u root -p"${MYSQL_ROOT_PASSWORD:-RootPass@123}" \
            --all-databases \
            --single-transaction \
            --routines \
            --triggers \
            --events \
            > "${BACKUP_DIR}/mysql_backup.sql"
        
        log "Backup Moodle config..."
        cp "${INSTALL_DIR}/moodle/config/config.php" "${BACKUP_DIR}/"
        cp "${INSTALL_DIR}/.env" "${BACKUP_DIR}/"
        
        log "Backup moodledata (dari CubeFS)..."
        if mountpoint -q "/mnt/cubefs-moodledata" 2>/dev/null; then
            tar -czf "${BACKUP_DIR}/moodledata.tar.gz" -C "/mnt/cubefs-moodledata" .
        else
            warn "CubeFS tidak ter-mount, skip backup moodledata"
        fi
        
        log "Backup selesai di: ${BACKUP_DIR}"
        du -sh "$BACKUP_DIR"
        ;;

    restore)
        BACKUP_FILE="${2:-}"
        [ -z "$BACKUP_FILE" ] && error "Tentukan file backup: $0 restore /path/to/mysql_backup.sql"
        [ ! -f "$BACKUP_FILE" ] && error "File tidak ditemukan: $BACKUP_FILE"
        
        warn "PERINGATAN: Ini akan menimpa database yang ada!"
        read -p "Lanjutkan? (y/N): " confirm
        [[ "$confirm" =~ ^[Yy]$ ]] || exit 0
        
        log "Restore MySQL..."
        docker exec -i moodle-mysql-primary mysql \
            -u root -p"${MYSQL_ROOT_PASSWORD:-RootPass@123}" \
            < "$BACKUP_FILE"
        log "Restore selesai!"
        ;;

    moodle-cron)
        log "Menjalankan Moodle cron..."
        docker exec moodle-node1 sudo -u www-data php /var/www/html/admin/cli/cron.php
        log "Cron selesai"
        ;;

    db-shell)
        log "Membuka MySQL shell..."
        docker exec -it moodle-mysql-primary \
            mysql -u root -p"${MYSQL_ROOT_PASSWORD:-RootPass@123}" moodle
        ;;

    redis-cli)
        log "Membuka Redis CLI..."
        docker exec -it moodle-redis \
            redis-cli -a "${REDIS_PASSWORD:-RedisPass@123}"
        ;;

    purge-cache)
        log "Membersihkan cache Moodle di semua nodes..."
        for node in moodle-node1 moodle-node2 moodle-node3; do
            if docker ps -q -f name="$node" &>/dev/null; then
                docker exec "$node" sudo -u www-data php /var/www/html/admin/cli/purge_caches.php
                log "Cache dibersihkan di ${node}"
            fi
        done
        
        log "Membersihkan Redis cache..."
        docker exec moodle-redis redis-cli -a "${REDIS_PASSWORD:-RedisPass@123}" FLUSHDB
        log "Cache Moodle berhasil dibersihkan ✓"
        ;;

    upgrade)
        warn "Upgrade Moodle memerlukan downtime singkat!"
        read -p "Lanjutkan? (y/N): " confirm
        [[ "$confirm" =~ ^[Yy]$ ]] || exit 0
        
        log "Mengaktifkan maintenance mode..."
        docker exec moodle-node1 sudo -u www-data php /var/www/html/admin/cli/maintenance.php --enable
        
        log "Backup database sebelum upgrade..."
        $0 backup
        
        log "Pull image terbaru..."
        docker compose -f "${INSTALL_DIR}/docker-compose.moodle.yml" pull
        
        log "Rebuild & restart nodes satu per satu (rolling update)..."
        for node in moodle1 moodle2 moodle3; do
            log "Upgrade node: ${node}..."
            docker compose -f "${INSTALL_DIR}/docker-compose.moodle.yml" \
                up -d --no-deps --build "$node"
            sleep 20
        done
        
        log "Jalankan database upgrade..."
        docker exec moodle-node1 sudo -u www-data php /var/www/html/admin/cli/upgrade.php --non-interactive
        
        log "Nonaktifkan maintenance mode..."
        docker exec moodle-node1 sudo -u www-data php /var/www/html/admin/cli/maintenance.php --disable
        
        log "Upgrade selesai! ✓"
        ;;

    help|--help|-h|*)
        usage
        ;;
esac

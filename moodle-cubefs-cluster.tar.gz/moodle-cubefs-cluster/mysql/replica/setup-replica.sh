#!/bin/bash
# Setup MySQL Replication pada Replica Node

MASTER_HOST="${MYSQL_MASTER_HOST:-mysql-primary}"
REPL_USER="${MYSQL_REPLICATION_USER:-replicator}"
REPL_PASS="${MYSQL_REPLICATION_PASSWORD:-ReplPass@123}"
ROOT_PASS="${MYSQL_ROOT_PASSWORD:-RootPass@123}"

echo "[Replica Setup] Menunggu master siap..."
sleep 10

echo "[Replica Setup] Mengkonfigurasi GTID-based replication..."

mysql -u root -p"${ROOT_PASS}" <<-EOSQL
    STOP SLAVE;
    RESET SLAVE ALL;
    CHANGE MASTER TO
        MASTER_HOST='${MASTER_HOST}',
        MASTER_PORT=3306,
        MASTER_USER='${REPL_USER}',
        MASTER_PASSWORD='${REPL_PASS}',
        MASTER_AUTO_POSITION=1,
        MASTER_CONNECT_RETRY=10;
    START SLAVE;
    SHOW SLAVE STATUS\G;
EOSQL

echo "[Replica Setup] Replication dikonfigurasi!"

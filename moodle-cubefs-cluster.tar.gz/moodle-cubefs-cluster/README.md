# Moodle Clustering dengan CubeFS Shared Storage (Docker)

## Arsitektur

```
                    ┌─────────────────┐
                    │   Nginx (LB)    │
                    │   Port 80/443   │
                    └────────┬────────┘
                             │
              ┌──────────────┼──────────────┐
              │              │              │
    ┌─────────▼──┐  ┌────────▼───┐  ┌──────▼─────┐
    │ Moodle-1   │  │ Moodle-2   │  │ Moodle-3   │
    │ Port 8001  │  │ Port 8002  │  │ Port 8003  │
    └─────────┬──┘  └────────┬───┘  └──────┬─────┘
              │              │              │
              └──────────────┼──────────────┘
                             │ (CubeFS FUSE Mount)
                    ┌────────▼────────┐
                    │   CubeFS        │
                    │   Master x3     │
                    │   MetaNode x3   │
                    │   DataNode x3   │
                    └─────────────────┘
                             │
                    ┌────────▼────────┐
                    │   MySQL Cluster │
                    │   Primary +     │
                    │   Replica       │
                    └─────────────────┘
```

## Komponen
- **Nginx**: Load balancer untuk Moodle nodes
- **Moodle**: 3 instance aplikasi (horizontal scaling)
- **CubeFS**: Distributed shared storage (moodledata)
- **MySQL**: Primary-Replica database cluster
- **Redis**: Session sharing antar Moodle nodes

## Persyaratan
- Docker Engine >= 20.10
- Docker Compose >= 2.0
- RAM minimal 16GB
- Disk minimal 100GB
- OS: Linux (Ubuntu 20.04/22.04 direkomendasikan)
- FUSE kernel module terinstall

## Cara Install
Lihat `install.sh` untuk instalasi otomatis.

#!/bin/bash
# ============================================================
# Moodle Docker Entrypoint Script
# Menginisialisasi Moodle saat container pertama kali berjalan
# ============================================================

set -e

NODE_ID="${NODE_ID:-1}"
DB_HOST="${MOODLE_DB_HOST:-mysql-primary}"
DB_PORT="${MOODLE_DB_PORT:-3306}"
DB_NAME="${MOODLE_DB_NAME:-moodle}"
DB_USER="${MOODLE_DB_USER:-moodle}"
DB_PASS="${MOODLE_DB_PASSWORD:-}"
ADMIN_USER="${MOODLE_ADMIN_USER:-admin}"
ADMIN_PASS="${MOODLE_ADMIN_PASSWORD:-Admin@Moodle123}"
ADMIN_EMAIL="${MOODLE_ADMIN_EMAIL:-admin@example.com}"
SITE_NAME="${MOODLE_SITE_NAME:-Moodle LMS}"
WWWROOT="${MOODLE_WWWROOT:-http://localhost}"
DATAROOT="${MOODLE_DATAROOT:-/var/moodledata}"

# Warna output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

log() { echo -e "${GREEN}[Moodle Node ${NODE_ID}]${NC} $1"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
error() { echo -e "${RED}[ERROR]${NC} $1"; exit 1; }

log "Starting Moodle Node ${NODE_ID} initialization..."

# ─── Tunggu Database Ready ────────────────────────────────────
log "Waiting for MySQL at ${DB_HOST}:${DB_PORT}..."
MAX_RETRIES=60
RETRY=0
until mysql -h "$DB_HOST" -P "$DB_PORT" -u "$DB_USER" -p"$DB_PASS" -e "SELECT 1" "$DB_NAME" &>/dev/null; do
    RETRY=$((RETRY + 1))
    if [ $RETRY -ge $MAX_RETRIES ]; then
        error "MySQL tidak tersedia setelah ${MAX_RETRIES} percobaan"
    fi
    warn "MySQL belum siap (percobaan ${RETRY}/${MAX_RETRIES})... tunggu 5 detik"
    sleep 5
done
log "MySQL tersedia!"

# ─── Tunggu Redis Ready ──────────────────────────────────────
REDIS_HOST="${REDIS_HOST:-redis}"
REDIS_PORT="${REDIS_PORT:-6379}"
REDIS_PASS="${REDIS_PASSWORD:-}"
log "Waiting for Redis at ${REDIS_HOST}:${REDIS_PORT}..."
RETRY=0
until redis-cli -h "$REDIS_HOST" -p "$REDIS_PORT" -a "$REDIS_PASS" ping &>/dev/null; do
    RETRY=$((RETRY + 1))
    if [ $RETRY -ge 30 ]; then
        warn "Redis tidak tersedia, melanjutkan tanpa cache..."
        break
    fi
    sleep 2
done

# ─── Setup Moodledata Directory ──────────────────────────────
log "Setting up moodledata directory at ${DATAROOT}..."
mkdir -p "${DATAROOT}"/{filedir,temp,cache,sessions,localcache,trashdir,repository}
chown -R www-data:www-data "${DATAROOT}"
chmod -R 2777 "${DATAROOT}"

# ─── Instalasi Moodle (hanya Node 1) ─────────────────────────
INSTALL_FLAG="${DATAROOT}/.moodle_installed"

if [ "$NODE_ID" -eq 1 ] && [ ! -f "$INSTALL_FLAG" ]; then
    log "Node 1: Melakukan instalasi Moodle pertama kali..."
    
    sudo -u www-data php /var/www/html/admin/cli/install.php \
        --wwwroot="${WWWROOT}" \
        --dataroot="${DATAROOT}" \
        --dbtype="mysqli" \
        --dbhost="${DB_HOST}" \
        --dbport="${DB_PORT}" \
        --dbname="${DB_NAME}" \
        --dbuser="${DB_USER}" \
        --dbpass="${DB_PASS}" \
        --prefix="mdl_" \
        --fullname="${SITE_NAME}" \
        --shortname="moodle" \
        --adminuser="${ADMIN_USER}" \
        --adminpass="${ADMIN_PASS}" \
        --adminemail="${ADMIN_EMAIL}" \
        --agree-license \
        --non-interactive 2>&1 || error "Instalasi Moodle gagal!"
    
    # Tambahkan Redis caching ke config via CLI
    sudo -u www-data php /var/www/html/admin/cli/cfg.php \
        --component=core \
        --name=cachestore_redis_testservers \
        --set="${REDIS_HOST}:${REDIS_PORT}" 2>/dev/null || true
    
    # Tandai sudah terinstall
    touch "$INSTALL_FLAG"
    log "Instalasi Moodle selesai!"

elif [ "$NODE_ID" -ne 1 ]; then
    log "Node ${NODE_ID}: Menunggu Node 1 menyelesaikan instalasi..."
    MAX_WAIT=300
    WAITED=0
    until [ -f "$INSTALL_FLAG" ]; do
        sleep 5
        WAITED=$((WAITED + 5))
        if [ $WAITED -ge $MAX_WAIT ]; then
            warn "Timeout menunggu instalasi Node 1, melanjutkan..."
            break
        fi
    done
    log "Node ${NODE_ID}: Moodle sudah terinstall, melanjutkan..."

else
    log "Moodle sudah terinstall sebelumnya."
fi

# ─── Upgrade Database jika perlu ─────────────────────────────
if [ "$NODE_ID" -eq 1 ]; then
    log "Menjalankan database upgrade check..."
    sudo -u www-data php /var/www/html/admin/cli/upgrade.php \
        --non-interactive 2>&1 || warn "Upgrade check gagal atau tidak diperlukan"
fi

# ─── Set Permissions ─────────────────────────────────────────
log "Memperbaiki permissions..."
chown -R www-data:www-data /var/www/html
chown -R www-data:www-data "${DATAROOT}"
chmod -R 2777 "${DATAROOT}"

# ─── Configure Redis MUC (Moodle Universal Cache) ────────────
if [ "$NODE_ID" -eq 1 ]; then
    log "Mengkonfigurasi Redis cache store..."
    sudo -u www-data php /var/www/html/admin/cli/cfg.php \
        --component=cachestore_redis \
        --name=server \
        --set="${REDIS_HOST}:${REDIS_PORT}" 2>/dev/null || true
fi

# ─── Setup PHP Log Directory ─────────────────────────────────
mkdir -p /var/log/php
chown www-data:www-data /var/log/php

log "Moodle Node ${NODE_ID} siap! Memulai services..."
exec "$@"
